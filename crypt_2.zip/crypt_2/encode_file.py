from crypte import encode_file
encode_file()