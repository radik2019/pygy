from crypte import decode_file
decode_file()